package mydb.exceptions;

public class BadRecordException extends RuntimeException{
    BadRecordException(String msg){
        super(msg);
    }
}
